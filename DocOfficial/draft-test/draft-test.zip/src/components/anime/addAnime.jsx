import React , { useState} from 'react'

export default function addAnime() {

    const [newAnime , setNewAnime] = useState({});
  
    return (
        <div className="add-anime">
            <form action="">
                <div className="row">
                    <label className="col">photo</label>
                    <input type="text" name="" id=""/>
                </div>
                <div className="row">
                     <label className="col">nmae</label>
                    <input type="text" name="" id=""/>
                </div>
                <button className="tt"> sfsdfsdf sdf sdf sdf </button>
            </form>
        </div>
    )
}
