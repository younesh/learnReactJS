import React, { Component } from 'react'

export class testpdt extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default testpdt
